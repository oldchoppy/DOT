import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.serial.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class GUI13 extends PApplet {



PShape button_check;
PShape button_slot;
PShape button_indicator;
int button_pos_x=20;
int button_pos_y=20;
int button_pos_y2=60;
int button_width=50;
int button_height=25;
int button_status;
String button_title1="BUTTON 1";
String button_title2="BUTTON 2";
String button_title_save="SAVE";
String button_title_load="LOAD";
String button_title_print="PRINT";
int button_corner=10;
int[] button_color_false={0,125,255};
int[] button_color_true={145,200,255};
int button_menu_width=80;
int button_menu_height=40;
int window_sketch_x=20;
int window_sketch_y=150;
int window_sketch_width=750;
int window_sketch_height=475;
String window_sketch_title="Sketch Window:";
int window_sketch_bounds_x;
int window_sketch_bounds_y;
int window_sketch_flag=0;
int window_sketch_coordinate_x;
int window_sketch_coordinate_y;
int window_sketch_coordinate_x_close;
int window_sketch_coordinate_y_close;
int window_sketch_coordinate_x_previous;
int window_sketch_coordinate_y_previous;
int[] sketch_array_x=new int[1];
int[] sketch_array_y=new int[1];
int[] sketch_array_x2=new int[1];
int[] sketch_array_y2=new int[1];
int sketch_array_length;
int shape_complete=0;
PrintWriter GCODE;


public void setup() {
  //Serial Port1;
  //printArray(Serial.list());
  //Port1 = new Serial(this, Serial.list()[0], 9600);
  
  background(192,192,192);
  textSize(24);
  // Create Buttons
  button_create_ON(button_pos_x,button_pos_y,button_width,button_height,button_title1,button_corner);
  button_create_ON(button_pos_x,button_pos_y2,button_width,button_height,button_title2,button_corner);
  // Create Sketch Window
  sketch_window_create();
  //SETUP GCODE FILE
  GCODE_FILE_SETUP();
  //CREATE SAVE BUTTON IN OFF POSITION
  button_menu_create_save_OFF();
  //CREATE LOAD BUTTON IN OFF POSITION
  button_menu_create_load_OFF();
  //CREATE PRINT BUTTON IN OFF POSITION
  button_menu_create_print_OFF();
}

public void draw(){
  button_update(); //update the button 1 every loop
  button_menu_save_update();//update the save button
  button_menu_load_update();//update the load button
  button_menu_print_update();//update the print button
  sketch();
  GCODE();
  GCODE_PRINT();
}
//_________________________________________________________________
//This function updates the PRINT button
public void button_menu_print_update(){
  if((mousePressed==true)&&(mouseButton==LEFT)&&(mouseX>window_sketch_x+200)&&(mouseX<window_sketch_x+button_menu_width+200)&&(mouseY>window_sketch_y+window_sketch_height+20)&&mouseY<window_sketch_y+window_sketch_height+20+button_menu_height){
   button_menu_create_print_ON();
  }else{
   button_menu_create_print_OFF();
  }
}
//_________________________________________________________________
//This function will create a PRINT button in ON state
public void button_menu_create_print_ON(){
  button_menu_create(window_sketch_x+200,window_sketch_y+window_sketch_height+20,button_menu_width,button_menu_height,button_title_print,button_color_true[0],button_color_true[1],button_color_true[2]);
}
//_________________________________________________________________
//This Function will create a PRINT button in OFF state
public void button_menu_create_print_OFF(){
  button_menu_create(window_sketch_x+200,window_sketch_y+window_sketch_height+20,button_menu_width,button_menu_height,button_title_print,button_color_false[0],button_color_false[1],button_color_false[2]);
}
//_________________________________________________________________
//This function updates the LOAD button
public void button_menu_load_update(){
  if((mousePressed==true)&&(mouseButton==LEFT)&&(mouseX>window_sketch_x+100)&&(mouseX<window_sketch_x+button_menu_width+100)&&(mouseY>window_sketch_y+window_sketch_height+20)&&mouseY<window_sketch_y+window_sketch_height+20+button_menu_height){
   button_menu_create_load_ON();
  }else{
    button_menu_create_load_OFF();
  }
}
//_________________________________________________________________
//This function will create a LOAD button in ON state
public void button_menu_create_load_ON(){
  button_menu_create(window_sketch_x+100,window_sketch_y+window_sketch_height+20,button_menu_width,button_menu_height,button_title_load,button_color_true[0],button_color_true[1],button_color_true[2]);
}
//_________________________________________________________________
//This Function will create a LOAD button in OFF state
public void button_menu_create_load_OFF(){
  button_menu_create(window_sketch_x+100,window_sketch_y+window_sketch_height+20,button_menu_width,button_menu_height,button_title_load,button_color_false[0],button_color_false[1],button_color_false[2]);
}
//_________________________________________________________________
//This function updates the SAVE button
public void button_menu_save_update(){
  if((mousePressed==true)&&(mouseButton==LEFT)&&(mouseX>window_sketch_x)&&(mouseX<window_sketch_x+button_menu_width)&&(mouseY>window_sketch_y+window_sketch_height+20)&&mouseY<window_sketch_y+window_sketch_height+20+button_menu_height){
   button_menu_create_save_ON();
  }else{
    button_menu_create_save_OFF();
  }
}
//_________________________________________________________________
//This function will create a SAVE button in ON state
public void button_menu_create_save_ON(){
  button_menu_create(window_sketch_x,window_sketch_y+window_sketch_height+20,button_menu_width,button_menu_height,button_title_save,button_color_true[0],button_color_true[1],button_color_true[2]);
}
//_________________________________________________________________
//This Function will create a SAVE button in OFF state
public void button_menu_create_save_OFF(){
  button_menu_create(window_sketch_x,window_sketch_y+window_sketch_height+20,button_menu_width,button_menu_height,button_title_save,button_color_false[0],button_color_false[1],button_color_false[2]);
}
//_________________________________________________________________
//THIS FUNCTION WILL CREATE A MENU BUTTON. NON-TOGGLE STYLE.
public void button_menu_create(int x, int y, int button_menu_width, int button_menu_height, String button_menu_title,int color1,int color2, int color3){
  fill(color1,color2,color3);
  rect(x,y,button_menu_width,button_menu_height,button_corner);
  fill(0,0,0);
  textSize(24);
  text(button_menu_title,x+10,y+30);
}
//_________________________________________________________________
//THIS FUNCTION WILL PRINT ANYTHING IN THE GCODE FILE
public void GCODE_PRINT(){
  if(shape_complete==2){
    String line_txt[] = loadStrings("GCODE/GCODE.txt");
    for(int i=0;i<line_txt.length;i++){
      println(line_txt[i]);
      delay(500);
      shape_complete=0;
      //GCODE_FILE_SETUP();
    }
  }  
}

//_________________________________________________________________
//This function creates a text file with GCODE. ANY Setup GCODE Commands must be sent here.
public void GCODE_FILE_SETUP(){
 GCODE=createWriter("GCODE/GCODE.txt");
 GCODE.println("G20");//INCHES
 GCODE.println("G28");//Go Home
 GCODE.println("G90");//USE ABSOLUTE COORDINATES
}
//_________________________________________________________________
//This function generates GCODE from the Vertex Array
public void GCODE(){
  if(shape_complete==1){
    for(int i=0;i<sketch_array_x.length;i++){
      GCODE.print("G00");
      GCODE.print(" X");
      GCODE.print(sketch_array_x[i]);
      GCODE.print(" Y");
      GCODE.println(sketch_array_y[i]);
   }
       sketch_array_x=new int[1];
       sketch_array_y=new int[1];
       sketch_array_x2=new int[1];
       sketch_array_y2=new int[1];
       shape_complete=2;
       GCODE.flush();
       GCODE.close();
}
}



//_________________________________________________________________
//This Function builds an array of coordinates from a polygon 
public void sketch(){
  //if the mouse is inside the sketch area and clicked the left button
  if((mousePressed==true)&&(mouseButton==LEFT)&&(mouseX>window_sketch_x)&&(mouseX<window_sketch_bounds_x)&&(mouseY>window_sketch_y)&&mouseY<window_sketch_bounds_y){
    //if the sketch flag is zero begin a new shape with no fill set sketch flag to one
    if(window_sketch_flag==0){
      noFill();
      beginShape();
    }
  //set the vertex to the coordinates of the mouse
    window_sketch_coordinate_x=mouseX;
    window_sketch_coordinate_y=mouseY;
    vertex(window_sketch_coordinate_x, window_sketch_coordinate_y);
    //if this is a new sketch start building a new array of coordinates
    if(window_sketch_flag==0){
      sketch_array_x[0]=window_sketch_coordinate_x;
      sketch_array_y[0]=window_sketch_coordinate_y;
      window_sketch_coordinate_x_close=window_sketch_coordinate_x;
      window_sketch_coordinate_y_close=window_sketch_coordinate_y; 
  }
    //if this is a sketch that has already started continue building the array
    if(window_sketch_flag==1){
      sketch_array_x2[0]=window_sketch_coordinate_x;
      sketch_array_y2[0]=window_sketch_coordinate_y;
      if ((window_sketch_coordinate_x!=window_sketch_coordinate_x_previous)&&(window_sketch_coordinate_y!=window_sketch_coordinate_y_previous)){
      sketch_array_x=append(sketch_array_x,sketch_array_x2[0]);  
      sketch_array_y=append(sketch_array_y,sketch_array_y2[0]); 
      }
  }
    window_sketch_flag=1;
  }
  //if the right mouse button is pressed close the shape and finish building the array
    if((mousePressed==true)&&(mouseButton==RIGHT)&&(mouseX>window_sketch_x)&&(mouseX<window_sketch_bounds_x)&&(mouseY>window_sketch_y)&&mouseY<window_sketch_bounds_y&&shape_complete==0){
    noFill();
    endShape(CLOSE);
    window_sketch_flag=0;
    sketch_array_x2[0]=window_sketch_coordinate_x_close;
    sketch_array_y2[0]=window_sketch_coordinate_y_close;
    sketch_array_x=append(sketch_array_x,sketch_array_x2[0]);
    sketch_array_y=append(sketch_array_y,sketch_array_y2[0]);
    shape_complete=1;
    //println(sketch_array_x);
    //println(sketch_array_y);
    }
    window_sketch_coordinate_x_previous=window_sketch_coordinate_x;
    window_sketch_coordinate_y_previous=window_sketch_coordinate_y;
}
//______________________________________________________________
//create a sketch window to draw inside
public void sketch_window_create(){
  text(window_sketch_title, 300, window_sketch_y-20);
  rect(window_sketch_x,window_sketch_y,window_sketch_width,window_sketch_height,button_corner);
  window_sketch_bounds_x=window_sketch_x+window_sketch_width;
  window_sketch_bounds_y=window_sketch_y+window_sketch_height;
}

//_______________________________________________________________
//update the button picture on the screen
public void button_update(){
  fill(255,255,255);
  switch(button_status){//toggle the button ON and OFF if the mouse is pressed on the button
    case 0:
    if ((mouseX>button_pos_x&&mouseX<(button_pos_x+button_width))&&(mouseY>button_pos_y&&mouseY<(button_pos_y+button_height))&&(mousePressed==true)){
    button_create_ON(button_pos_x,button_pos_y,button_width,button_height,button_title1,button_corner);
  delay(150);  
  }
    break;
    case 1:
    if ((mouseX>button_pos_x&&mouseX<(button_pos_x+button_width))&&(mouseY>button_pos_y&&mouseY<(button_pos_y+button_height))&&(mousePressed==true)){
    button_create_OFF(button_pos_x,button_pos_y,button_width,button_height,button_title1,button_corner);
  delay(150);  
  }
    break;
}
}

//_______________________________________________________________
//create a new button that is ON
public void button_create_ON(int x, int y, int button_width, int button_height, String button_title,int button_corner){
  button_check=createShape(GROUP);
  button_slot=createShape(RECT, x, y, button_width, button_height,button_corner);
  button_slot.setFill(color(0,128,255));
  button_indicator=createShape(ARC, x+12, y+12, 20, 20, 0, TWO_PI);
  button_check.addChild(button_slot);
  button_check.addChild(button_indicator);
  shape(button_check);
  button_status=1;
  text(button_title,button_width+x+15,y+15);
}

//_________________________________________________________________
//create a new button that is OFF
public void button_create_OFF(int x,int y,int button_width, int button_height,String button_title, int button_corner){
  button_check=createShape(GROUP);
  button_slot=createShape(RECT, x, y, button_width,button_height,button_corner);
  button_slot.setFill(color(0,128,255));
  button_indicator=createShape(ARC, x+38, y+12, 20, 20, 0, TWO_PI);
  button_check.addChild(button_slot);
  button_check.addChild(button_indicator);
  shape(button_check);
  button_status=0;
  text(button_title,button_width+x+15,y+15);
}
  
  public void settings() {  size(1024,768); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "GUI13" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
